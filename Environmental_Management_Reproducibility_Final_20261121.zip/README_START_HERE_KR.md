# Environmental Management: 재현자료 전용 패키지 (논문 미포함)

이 ZIP은 투고용 논문 파일을 **포함하지 않습니다**. 최종 논문은 `Environmental_Management_SSCI_Styled_Final_20261121.docx`라는 별도 Word 파일로 제공됩니다. 기존 관광·환경 연구의 분석자료·코드·보관된 결과를 사용하며, 본 패키지는 논문 텍스트를 자동으로 생성하거나 수정하지 않습니다.

## 폴더/파일 구성

- `FINAL_DATASET_183_NUTS2.csv`: 최종 분석 지역 183개를 담은 기본 데이터셋(바로 열어볼 수 있는 CSV).
- `FINAL_ANNUAL_PANEL_2018_2025.csv`: 1,464개 지역-연도 관측치 CSV.
- `Tourism_Environment_NUTS2_Datasets_20261116.xlsx`: 지역 단면, 연도 패널, 250 후보 지역과 변수 정의 등을 담은 기존 데이터셋 워크북.
- `data/nuts2_analysis_183regions.csv`: 21개국 NUTS 2 지역 183개 단면 분석자료.
- `data/nuts2_annual_panel_1464.csv`: 2018–2025년의 1,464개 지역-연도 관측치.
- `data/eurostat_studyframe_250_nuts2_source_cells.csv`: 후보 250개 지역의 연구용 원천 데이터 셀 및 결측.
- `data/`: 원천 추출물, 국가·지역 지도 점, 경계개정 점검 입력자료.
- `scripts/`: 회귀분석, 다중검정, 국가별 홀드아웃 교차검증, 전쟁 및 경계변경 강건성 점검, 결과 검증 코드.
- `results/`: 회귀결과, 머신러닝 평가, 표본 선별 및 강건성 결과 CSV/JSON.
- `figures/`: 기존 분석 도표와 지역 지도 이미지. `figures/manuscript/`에는 원고 Fig. 1–5에 대응하는 최종 PNG·SVG와 보충 계수대조 그림을 저장.
- `ESM_1.pdf`: 원고에서 인용한 Online Resource 1 보충자료(표본·분석·강건성·자료제약).
- `scripts/render_publication_figures.py`: 최종 그림을 데이터에서 다시 생성하는 코드.
- `scripts/validate_manuscript_tables.py`: ZIP 밖의 Word 파일과 결과 CSV 사이에 있는 표 수치를 교차 검증하는 코드.
- `results/MANUSCRIPT_TABLE_NUMERIC_QA.csv`: 최종 원고의 표 2–8 숫자 183개 대조 기록.
- `FRESH_REPLAY_20261121.log`: 최종 환경에서의 오프라인 전체 실행 로그.
- `DATA_DICTIONARY.csv`, `SOURCE_PROVENANCE.md`, `NUTS_BOUNDARY_AND_SOURCE_AUDIT_KR_20261115.md`: 변수와 출처·한계 기록.
- `MANIFEST_SHA256.csv`: 포함된 파일의 SHA-256 해시와 파일 크기.

## 실행 방법

1. 압축을 풀고, Python 3.13 및 `requirements.txt`에 명시된 라이브러리를 준비합니다.
2. `python -m pip install -r requirements.txt`를 실행합니다.
3. Windows는 `run_all_windows.bat`, macOS/Linux는 `bash run_all_macos_linux.sh`를 실행합니다.
4. 실행 후 `results/`와 `figures/`에서 생성된 출력과 원래 보관된 수치를 대조합니다.
5. 숫자 검증만 빠르게 하려면 `python scripts/verify_results.py`와 `python scripts/geo_boundary_reference_audit.py`를 실행합니다.
6. 최종 Word를 압축파일 외부에 두고 표 수치를 확인하려면 `python scripts/validate_manuscript_tables.py /경로/Environmental_Management_SSCI_Styled_Final_20261121.docx`을 실행합니다.
7. 전체 재실행은 최종 원고의 표와 그림을 다시 작성하지 않습니다. 별도 Word 원고는 유지하고, `figures/manuscript/` 그림만 다시 생성합니다.

## 반드시 명시할 제한

- 183개 지역/21개국/1,464개 연도 관측치에 대한 **보존 분석자료 기반 오프라인 재현**을 지원합니다.
- 후보 250개 자료는 최초 고정한 183개 선택 지역의 원천 셀과 이후 확인한 67개 미선정 지역의 셀을 결합한 것으로, 당시 Eurostat 전체 무필터 API JSON 응답을 그대로 보관한 것은 아닙니다.
- NUTS 2016/2021/2024의 공식 변경기록과 보수적인 제외검정은 포함하지만, 과거 지리 경계를 모든 연도에서 동일한 폴리곤으로 면적 가중 일치시킨 것은 아닙니다.
- 기존 로그 및 결과는 2026-11-16 당시 보존된 기록이고, `FRESH_REPLAY_20261121.log`는 이 패키지에 대해 다시 수행한 실행 기록입니다. 외부 데이터가 개정되면 나중에 새로 내려받는 원천자료는 기존 결과와 달라질 수 있습니다.
- 논문의 최종 편집(영어 문장, 참고문헌과 표 서식)은 수치 재현 프로그램과 별개입니다. 논문 제출용 원고는 ZIP 바깥의 Word 파일을 사용해야 합니다.
- 원자료 재배포 허용 범위, 데이터 출처 및 AI 활용 고지의 최종 확인은 저자가 수행해야 합니다.
