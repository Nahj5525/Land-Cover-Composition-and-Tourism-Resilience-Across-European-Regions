#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 scripts/run_analysis.py
python3 scripts/additional_checks.py
python3 scripts/verify_results.py
python3 scripts/ukraine_war_analysis.py
python3 scripts/geo_boundary_reference_audit.py
python3 scripts/render_regional_maps.py
python3 scripts/render_publication_figures.py
python3 scripts/recheck_studyframe_and_nuts_changes.py
python3 scripts/verify_war_revision.py
echo "PASS: analysis and numerical validation completed. Manuscript is distributed separately."
