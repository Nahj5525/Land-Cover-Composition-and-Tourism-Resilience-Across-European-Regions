# Data and source provenance (14 November 2026)

1. Eurostat tourism nights: public data table tgs00111, source `tour_occ_nin2`. URL: https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/tgs00111?lang=EN&geoLevel=nuts2&sinceTimePeriod=2018
   - Source dataset update reported by API: 2026-10-20, 23:00 +0200.
   - Dimensions: frequency A, residence TOTAL and FOR, unit NR, NACE I551–I553, NUTS 2 regions, annual 2018–2025.
   - The source archive `regional_source_encoded.txt` retains selected 2018, 2019, 2020, 2024 and 2025 TOTAL nights, 2019 foreign nights and original flags. The supplemental extract stores 2021–2023 TOTAL nights.
2. Eurostat LUCAS regional land-cover overview: `lan_lcv_ovw`. URL: https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lan_lcv_ovw?lang=EN&geoLevel=nuts2&time=2018
   - Source dataset update reported by API: 2025-07-25, 23:00 +0200.
   - Parameters: reference year 2018, unit PC, five classifications C00 woodland, B00 cropland, G00 water, A00 artificial, E00 grassland.
   - Archived percentages are encoded in units of one decimal (x10, base36); integer night counts are losslessly encoded base36.

The provided raw source inputs are **documented exact-cell extracts of the 183 selected regions**, not full downloaded Eurostat JSON response snapshots. The analysis can be exactly numerically reproduced from these files without internet access, but reconstructing the full candidate-region screening workflow or independently verifying historical Eurostat releases requires the provider's historical data and geography correspondence. Regional NUTS code matching does not harmonize boundary changes over time.

## Selection and release constraints
- Initial country list: AT, CY, CZ, DE, DK, ES, FI, FR, HR, HU, IT, LT, LU, LV, MT, NL, PL, PT, RO, SE, SI, SK (22).
- Included: 183 matched NUTS 2 regions from 21 countries, 2018–2025 balanced tourism panel (1,464 rows). Slovenia drops for lack of a qualifying common region in archived releases.
- No fabricated values; 17 matched regions have retained tourism-cell estimation/reliability flags, chiefly the French subsets; flagged observations are excluded in a sensitivity model.
- The unit of land cover is percentage points of regional area, **not** distance from guest establishments to a forest or shoreline.
- All outputs are observational; no causal claim is identified.


## 2022 onward Ukraine-war sensitivity sources (14 Nov 2026)
- Border-country definition PL/SK/HU/RO: European Commission (2026), https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:52026DC0082
- Invasion date 24 February 2022 and tourism treatment of displaced persons: Eurostat (2022), https://ec.europa.eu/eurostat/documents/14916382/15042455/Guidance-note-Ukraine-tourism.pdf/54d092c4-7aa7-6f0a-b6af-b338eceab7d3
- Tourism and regional impacts mechanism: OECD (2022), https://www.oecd.org/content/dam/oecd/en/publications/reports/2022/07/the-implications-for-oecd-regions-of-the-war-in-ukraine_09c96fae/8e0fcb83-en.pdf
- Related war/hotel-market study: Napierała & Pawlicz (2025), https://doi.org/10.1016/j.tourman.2025.105235
- `war_ua_land_border` is a pre-defined administrative indicator, not an observed measurement of intensity of war effects. No refugees are imputed as tourists.


## November 2026 NUTS geography and bibliography verification
See `NUTS_BOUNDARY_AND_SOURCE_AUDIT_KR_20261115.md`, `data/NUTS_VERSION_AUDIT_183.csv`, `results/NUTS_BOUNDARY_CONSERVATIVE_ROBUSTNESS.csv`, `results/REFERENCE_AUDIT_16.csv`. Run `python scripts/geo_boundary_reference_audit.py` to re-estimate and assert the boundary-exclusion sensitivity results. The checks establish code continuity and country-level exclusion robustness, **not exact boundary polygon equivalence**. The current Environmental Management manuscript is distributed as a separate Word file and is not included in this replication archive.

## GISCO location visualization and full-source screening (2026-11-14)
- GISCO label-point release: `https://gisco-services.ec.europa.eu/distribution/v2/nuts/geojson/NUTS_LB_2024_4326_LEVL_2.geojson`. Geo coordinates are rounded to 0.01 degrees in the archived point table and matched to 183 NUTS2 codes; marker location is the official label point, not a measured accommodation centroid.
- Background coast and country boundaries are low-resolution generalized Basemap/GSHHG linework, simplified to 0.08 degrees and archived as `data/europe_outline_simplified.json` to render the maps offline. The colors map real selected-region environmental and tourism observations. Neither GISCO points nor this background establish identical polygons across 2016/2021/2024.
- Source population screening independently checked against Eurostat JSON-stat response vintages: tourism API updated `2026-10-20T23:00:00+0200`; LUCAS landcover API updated `2025-07-25T23:00:00+0200`. Inclusion funnel: 250 (22-country candidate NUTS2 ids), 235 (code intersection), 191 (eight positive yearly totals), 186 (valid 2019 foreign share), 183 (complete five land covers); see `results/FULL_SOURCE_SCREENING_FUNNEL_VERIFIED.csv`. Original full unfiltered responses are NOT archived in this ZIP, only the selected value extracts; the new full-response downloader can capture a later release.


## Final replication archive clarification (2026-11-16)

The `data/eurostat_studyframe_250_nuts2_source_cells.csv` is a compact study-frame selection archive, combining the originally frozen 183 regional cells and the 67 additional nonselected candidate cells collected in a later provider extract. It is not a complete byte-for-byte Eurostat JSON-stat response from one historical vintage. The 250 → 235 → 191 → 186 → 183 sample screening is reproducible from these stored cells. All NUTS revisions are checked using published change logs and sample exclusions, not area-weighted polygon harmonization.
