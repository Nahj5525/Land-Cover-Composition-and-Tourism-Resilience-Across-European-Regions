# Tourism Environment: Reproduction test summary (2026-11-16)

- Environment: Python 3.13; versions pinned in `requirements.txt`.
- Executed: `bash run_all_macos_linux.sh` from the extracted package folder; exit code 0.
- Verified 250 candidate NUTS2 codes → 235 intersection → 191 positive nights → 186 valid 2019 foreign nights → 183 complete land-cover matches; 21 countries; panel 1,464 observations.
- Reran main country-FE regressions (country cluster inference, t with 20 df), model comparison, five-fold country-grouped holdouts, Ukraine-border contrasts, NUTS classification change screening, supplementary robustness, and map rendering.
- Primary 2020 woodland coefficient per 10 percentage points: +2.240178 log points, p≈0.02137; 2024 coefficient: −0.746698, p≈0.21225.
- Stacked 2024−2020 woodland coefficient contrast: −2.986876 log points; country-cluster p≈0.000737.
- Exclude two relevant code/boundary revision cases (ITH5, ITI3): n=181, coefficient contrast −2.933402, p≈0.000579.
- Country-held-out XGBoost MAE in 2020: 18.834177; 2024 training-fold mean baseline MAE: 6.646719.
- Validation scripts `verify_results.py`, `verify_war_revision.py`, and `verify_submission.py` passed against the final formatted manuscript.
- Analytic source cells, codes and published result tables are reproducible offline. The ZIP is not an archive of full unfiltered historical Eurostat API releases and does not contain complete polygon overlay harmonization across historical NUTS versions.

See `REPRODUCTION_FULL_RUN_20261116.log` for the actual console output.
