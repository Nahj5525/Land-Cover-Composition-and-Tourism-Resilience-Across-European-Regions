#!/usr/bin/env python3
"""Pre-specified-looking? NO: exploratory add-on for 2022 war exposure.
Associational analyses only, 2018-25 balanced NUTS2 183 regions; no claims of identification.
Recomputes directly from archived data/nuts2_{analysis,annual_panel}.csv.
"""
from pathlib import Path
import json, itertools, math
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data';OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
df=pd.read_csv(DATA/'nuts2_analysis_183regions.csv',encoding='utf-8-sig')
panel=pd.read_csv(DATA/'nuts2_annual_panel_1464.csv',encoding='utf-8-sig')
BORDER=['HU','PL','RO','SK']
assert len(df)==183 and len(panel)==1464 and df.country.nunique()==21
assert all(len(panel[panel.nuts2==r])==8 for r in df.nuts2)
df['war_ua_land_border']=df.country.isin(BORDER).astype(int)
panel['war_ua_land_border']=panel.country.isin(BORDER).astype(int)
panel['post_invasion_annual']=panel.year.ge(2022).astype(int)
panel['war_border_post2022']=panel.war_ua_land_border*panel.post_invasion_annual

# Phase-specific coefficients and formal 2020 vs 2024 cluster-robust Wald test.
cols=['nuts2','country','forest2018','foreign_share2019','pretrend_2018_2019','log_baseline2019','logratio2020','logratio2024']
stack=pd.concat([df[cols].rename(columns={'logratio2020':'y'}).drop(columns=['logratio2024']).assign(phase='2020'),df[cols].rename(columns={'logratio2024':'y'}).drop(columns=['logratio2020']).assign(phase='2024')],ignore_index=True)
form='y ~ forest2018*C(phase) + (foreign_share2019+pretrend_2018_2019+log_baseline2019)*C(phase) + C(country)*C(phase)'
m=smf.ols(form,stack).fit(cov_type='cluster',cov_kwds={'groups':stack.country,'use_correction':True},use_t=True)
term='forest2018:C(phase)[T.2024]'; ncl=df.country.nunique(); v=float(m.params[term]);se=float(m.bse[term]); tt=v/se; p=2*stats.t.sf(abs(tt),ncl-1)
phase={'comparison':'2024 minus 2020','coef_diff_per10pp':10*v,'se_diff_per10pp':10*se,'p_t20':p,'t20':tt,'num_regions':183,'countries':ncl,'coef_2020_per10pp':10*m.params['forest2018'],'coef_2024_per10pp':10*(m.params['forest2018']+v),'method':'Phase-stacked OLS; country-by-phase fixed effects, fully phase-specific covariates; country-clustered SE; t(20) for coefficient difference'}
pd.DataFrame([phase]).to_csv(OUT/'forest_phase_wald.csv',index=False,float_format='%.8f')

# For all 21 countries, contrast 2022-25 against immediate pre-war 2021; region and year fixed effects.
# Important: four treated-country clusters make asymptotic p-values fragile.
z=panel[panel.year.between(2021,2025)].copy()
for yr in [2022,2023,2024,2025]:z[f'border_{yr}']=((z.year==yr)&z.war_ua_land_border.eq(1)).astype(int)
for yr in [2022,2023,2024,2025]:
 for x in ['foreign_share2019','pretrend_2018_2019','log_baseline2019']:
  z[f'{x}_yr{yr}']=z[x]*(z.year==yr)
form='logratio_2019 ~ C(nuts2)+C(year) + '+' + '.join([f'border_{y}' for y in [2022,2023,2024,2025]])+' + '+' + '.join([f'{x}_yr{y}' for y in [2022,2023,2024,2025] for x in ['foreign_share2019','pretrend_2018_2019','log_baseline2019']])
w=smf.ols(form,z).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
rows=[]
for yr in [2022,2023,2024,2025]:
 term=f'border_{yr}'; beta=float(w.params[term]); se=float(w.bse[term]); p=2*stats.t.sf(abs(beta/se),20)
 rows.append(dict(year=yr,border_countries='PL,SK,HU,RO',N_regions=183,N_treated_regions=int(df.war_ua_land_border.sum()),N_treated_country_clusters=4,countries=21,coef_log_points=beta,se_cluster=se,p_cluster_t20=p,ref_year=2021,interpretation='relative additional rebound since 2021 in four adjacent countries; NOT causal war effect'))
pd.DataFrame(rows).to_csv(OUT/'war_border_vs2021_yearFE.csv',index=False,float_format='%.8f')

# Placebo and descriptive country-level exact permutation: equal-country weighting, no covariates.
# Country labels are not randomly assigned; permutation p is a sensitivity reference, not a causal p-value.
wc=df.groupby(['country','war_ua_land_border']).agg({f'logratio{y}':'mean' for y in range(2018,2026)}).reset_index()
all_ct=wc.country.tolist(); obs_set=set(BORDER); nT=len(BORDER)
permutations=list(itertools.combinations(range(len(all_ct)),nT))
mask=np.zeros((len(permutations),len(all_ct)),dtype=np.uint8)
for i,idx in enumerate(permutations):mask[i,list(idx)]=1
q=[]
for before,after in [(2018,2019),(2019,2020),(2020,2021),(2021,2022),(2021,2023),(2021,2024),(2021,2025)]:
 dif=(wc[f'logratio{after}']-wc[f'logratio{before}']).to_numpy()
 treated=wc.war_ua_land_border.to_numpy().astype(bool)
 delta=float(dif[treated].mean()-dif[~treated].mean())
 all_delta=(mask@dif)/nT-((1-mask)@dif)/(len(all_ct)-nT)
 exact_p=float((np.abs(all_delta)>=abs(delta)-1e-12).mean())
 q.append({'before':before,'after':after,'border_minus_other_change_log_points':delta,'exact_label_permutation_p':exact_p,'N_country_assignments':len(permutations),'countries_treated':4,'unit':'country mean unweighted','caveat':'Non-random geography: permutation is descriptive only; not a causal war p-value'})
pd.DataFrame(q).to_csv(OUT/'war_country_permutation_exploratory.csv',index=False,float_format='%.8f')

# Environmental coefficient robustness of main models when land-border countries omitted.
rob=[]
for year in [2020,2024,2025]:
 for spec in ['all_21_countries','exclude_4_ukraine_border_countries','only_4_ukraine_border_countries','exclude_FR_and_4_border_countries']:
  zz=df.copy()
  if spec=='exclude_4_ukraine_border_countries':zz=zz[zz.war_ua_land_border==0]
  elif spec=='only_4_ukraine_border_countries':zz=zz[zz.war_ua_land_border==1]
  elif spec=='exclude_FR_and_4_border_countries':zz=zz[(zz.war_ua_land_border==0)&zz.country.ne('FR')]
  fit=smf.ols(f'logratio{year} ~ forest2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)',data=zz).fit(cov_type='cluster',cov_kwds={'groups':zz.country,'use_correction':True},use_t=True)
  bb=float(fit.params['forest2018']);se=float(fit.bse['forest2018']);groups=zz.country.nunique();p=2*stats.t.sf(abs(bb/se),groups-1)
  rob.append(dict(year=year,specification=spec,N_regions=len(zz),countries=groups,coef_forest_10pp=10*bb,se_forest_10pp=10*se,p_country_cluster_t=p,flag='descriptive' if groups<=4 else ''))
pd.DataFrame(rob).to_csv(OUT/'forest_exclude_ukraine_border.csv',index=False,float_format='%.8f')

# Bounded data, clean documentation
(df[['nuts2','country','war_ua_land_border']]).to_csv(DATA/'ukraine_border_exposure.csv',index=False,encoding='utf-8-sig')
panel[['nuts2','country','year','nights','war_ua_land_border','post_invasion_annual','war_border_post2022']].to_csv(DATA/'regional_war_exposure_panel.csv',index=False,encoding='utf-8-sig')
summary={'phase_wald':phase,'war_border_annual_contrasts':rows,'war_border_country_perm':q,'environment_exclusions':rob,'sources':{'border_list':'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:52026DC0082','tourism_refugee_method':'https://ec.europa.eu/eurostat/documents/14916382/15042455/Guidance-note-Ukraine-tourism.pdf/54d092c4-7aa7-6f0a-b6af-b338eceab7d3?t=1662995612413'},'limitations':['No region-to-Ukraine distance and no NUTS historical boundary crosswalk','Small treatment group: four country clusters','Annual 2022 includes January and February before the 24 February invasion','Country-level post-2022 exposure may correlate with reopening, sanctions, prices, energy and refugee reception','Tourism-night data are intended to exclude refugee stays but measurement may differ by reporting','No causal war effect identified']}
(OUT/'WAR_REVISION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print('PHASE_WALD',phase)
print('WAR CONTRASTS\n',pd.DataFrame(rows).round(3).to_string(index=False))
print('PERMUTATION\n',pd.DataFrame(q).round(3).to_string(index=False))
print('FOREST ROBUSTNESS\n',pd.DataFrame(rob).round(3).to_string(index=False))
# Formal phase-difference sensitivity (uses same stacked model and covariance logic).
phase_rob=[]
for label, subset in [('full',df),('exclude_quality_flags',df[df.flag6=='______']),('exclude_border4',df[df.war_ua_land_border==0]),('exclude_france',df[df.country!='FR']),('countries_ge2',df[df.country.map(df.country.value_counts())>=2]),('exclude_border4_and_france',df[(df.war_ua_land_border==0)&(df.country!='FR')])]:
 ss=pd.concat([subset[cols].rename(columns={'logratio2020':'y'}).drop(columns=['logratio2024']).assign(phase='2020'),subset[cols].rename(columns={'logratio2024':'y'}).drop(columns=['logratio2020']).assign(phase='2024')],ignore_index=True)
 fm=smf.ols('y ~ forest2018*C(phase) + (foreign_share2019+pretrend_2018_2019+log_baseline2019)*C(phase) + C(country)*C(phase)',ss).fit(cov_type='cluster',cov_kwds={'groups':ss.country,'use_correction':True},use_t=True)
 delta=10*float(fm.params['forest2018:C(phase)[T.2024]']); std=10*float(fm.bse['forest2018:C(phase)[T.2024]']); n=subset.country.nunique(); pp=2*stats.t.sf(abs(delta/std),n-1)
 phase_rob.append({'spec':label,'N_regions':len(subset),'n_country_clusters':n,'forest_beta_2020_10pp':10*float(fm.params['forest2018']),'forest_beta_2024_10pp':10*float(fm.params['forest2018']+fm.params['forest2018:C(phase)[T.2024]']),'phase_difference_2024_minus_2020':delta,'SE_country_cluster':std,'p_t_clusters':pp})
pd.DataFrame(phase_rob).to_csv(OUT/'forest_phase_wald_robustness.csv',index=False,float_format='%.8f')
print('PHASE ROBUSTNESS\n',pd.DataFrame(phase_rob).round(4).to_string(index=False))
