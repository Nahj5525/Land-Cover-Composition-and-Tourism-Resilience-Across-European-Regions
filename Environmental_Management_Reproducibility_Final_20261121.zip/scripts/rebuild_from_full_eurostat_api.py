#!/usr/bin/env python3
"""Rebuild the eligible NUTS2 sample from TWO COMPLETE Eurostat JSON-stat releases.

Usage with internet access:
    python scripts/rebuild_from_full_eurostat_api.py --download
Offline reanalysis of previously downloaded full snapshots:
    python scripts/rebuild_from_full_eurostat_api.py

The files in data/full_source_downloads/ are the ENTIRE API responses (not the
archived subset). The script logs candidate exclusions and compares retained
source cells against the archived 183-region extract. It never silently alters
or overwrites the manuscript analysis dataset.
"""
from __future__ import annotations
import argparse, gzip, json, math, time, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'data'/'full_source_downloads'; SRC.mkdir(exist_ok=True,parents=True)
TOUR_URL='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/tgs00111?lang=EN&geoLevel=nuts2&sinceTimePeriod=2018'
LAND_URL='https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lan_lcv_ovw?lang=EN&geoLevel=nuts2&time=2018'
COUNTRIES='AT CY CZ DE DK ES FI FR HR HU IT LT LU LV MT NL PL PT RO SE SI SK'.split()
YEARS=list(range(2018,2026))
LAND={'forest2018':'C00','crop2018':'B00','water2018':'G00','artificial2018':'A00','grass2018':'E00'}

def request_full(url,path):
    last=None
    for k in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Research-reproducibility/1.0 (Eurostat public API)','Accept':'application/json'})
            with urllib.request.urlopen(req,timeout=90) as rsp:raw=rsp.read()
            j=json.loads(raw)
            if 'value' not in j or 'dimension' not in j:raise ValueError('Not a JSON-stat data response')
            with gzip.open(path,'wb') as f:f.write(raw)
            return j
        except (urllib.error.URLError,TimeoutError,ValueError) as e:
            last=e;time.sleep(2*(k+1))
    raise RuntimeError('Cannot download full API response. No silent fallback: '+str(last))

def open_full(path):
    with gzip.open(path,'rb') as f:return json.loads(f.read())

class JSONSTAT:
    def __init__(self,obj):
        self.d=obj; self.idx={x:obj['dimension'][x]['category']['index'] for x in obj['id']}
        self.sizes=obj['size'];self.ids=obj['id'];self.value=obj['value'];self.status=obj.get('status',{})
    def key(self,**filter):
        j=0
        for dim,sz in zip(self.ids,self.sizes):
            code=str(filter[dim]);ii=self.idx[dim].get(code)
            if ii is None:return None
            j=j*sz+int(ii)
        return str(j)
    def get(self,**filter):
        k=self.key(**filter)
        if k is None:return None,''
        return self.value.get(k),self.status.get(k,'')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--download',action='store_true',help='Fetch and archive both FULL live JSON responses');args=ap.parse_args()
    files=[SRC/'EUROSTAT_TOUR_TGS00111_FULL.json.gz',SRC/'EUROSTAT_LAND_LAN_LCV_OVW_FULL.json.gz']
    if args.download:
        tour=request_full(TOUR_URL,files[0]);land=request_full(LAND_URL,files[1])
    else:
        missing=[str(f) for f in files if not f.exists()]
        if missing:raise SystemExit('Missing complete JSON-stat releases; run --download with internet. Missing: '+', '.join(missing))
        tour=open_full(files[0]);land=open_full(files[1])
    t=JSONSTAT(tour); l=JSONSTAT(land)
    print('Downloaded releases:',tour.get('updated'),land.get('updated'))
    allregions=sorted(set(t.idx['geo'])|set(l.idx['geo']))
    audit=[];retained=[]
    for g in allregions:
        if len(g)!=4 or g[:2] not in COUNTRIES:continue
        ti=g in t.idx['geo'];la=g in l.idx['geo']
        entry={'nuts2':g,'country':g[:2],'tourism_code_exists':ti,'land_code_exists':la}
        vals={}; flags={}
        for y in YEARS:
            vals['n'+str(y)],flags['n'+str(y)]=t.get(freq='A',c_resid='TOTAL',unit='NR',nace_r2='I551-I553',geo=g,time=str(y))
        vals['foreign2019'],flags['foreign2019']=t.get(freq='A',c_resid='FOR',unit='NR',nace_r2='I551-I553',geo=g,time='2019')
        for name,cover in LAND.items():
            vals[name],_=l.get(freq='A',unit='PC',landcover=cover,geo=g,time='2018')
        def positive(x):return isinstance(x,(float,int)) and x>0 and math.isfinite(x)
        ok_anchor=all(positive(vals.get('n'+str(y))) for y in (2018,2019,2020,2024))
        ok_years=all(positive(vals.get('n'+str(y))) for y in YEARS)
        ok_foreign=vals['foreign2019'] is not None and isinstance(vals['foreign2019'],(float,int)) and vals['foreign2019']>=0 and positive(vals.get('n2019')) and vals['foreign2019']<vals['n2019']
        ok_forest=vals['forest2018'] is not None and isinstance(vals['forest2018'],(float,int)) and 0<=vals['forest2018']<=100
        ok_allland=all(isinstance(vals[x],(float,int)) and math.isfinite(vals[x]) for x in LAND)
        entry.update({'anchor_years_present':ok_anchor,'all_2018_2025_years_present':ok_years,'foreign_2019_available_lt_total':ok_foreign,'forest_2018_available':ok_forest,'five_land_covers_present':ok_allland,'selected':bool(ti and la and ok_anchor and ok_years and ok_foreign and ok_forest and ok_allland)})
        entry['exclusion_reason']=';'.join(key for key in ['tourism_code_exists','land_code_exists','anchor_years_present','all_2018_2025_years_present','foreign_2019_available_lt_total','forest_2018_available','five_land_covers_present'] if not entry[key]) or 'retained'
        audit.append(entry)
        if entry['selected']:
            retained.append({'nuts2':g,'country':g[:2],**vals,**{f'status_{k}':v for k,v in flags.items()}})
    a=pd.DataFrame(audit);r=pd.DataFrame(retained)
    a.to_csv(SRC/'all_candidate_eligibility.csv',index=False,encoding='utf-8-sig')
    r.to_csv(SRC/'live_rebuilt_source_cells.csv',index=False,encoding='utf-8-sig')
    frozen=pd.read_csv(ROOT/'data/nuts2_analysis_183regions.csv',encoding='utf-8-sig')
    same=set(frozen.nuts2)&set(r.nuts2); delta=[]
    for code in sorted(same):
        old=frozen.loc[frozen.nuts2==code].iloc[0];new=r.loc[r.nuts2==code].iloc[0]
        for name in [f'n{y}' for y in YEARS]+['foreign2019']+list(LAND):
            ov=float(old[name]); nv=float(new[name])
            # Land cover source is 0.1 percentage point precision
            diff=nv-ov
            if abs(diff)>(1e-6 if name.startswith('n') or name=='foreign2019' else 0.051):delta.append({'nuts2':code,'variable':name,'archived_value':ov,'live_value':nv,'difference':diff})
    pd.DataFrame(delta,columns=['nuts2','variable','archived_value','live_value','difference']).to_csv(SRC/'archived_vs_live_differences.csv',index=False)
    summary={'processed_at_utc':datetime.now(timezone.utc).isoformat(),'tourism_api':TOUR_URL,'land_api':LAND_URL,'tourism_updated':tour.get('updated'),'land_updated':land.get('updated'),'candidate_regions':len(a),'live_selected_regions':len(r),'live_selected_countries':r.country.nunique() if len(r) else 0,'archived_selected_regions':len(frozen),'archived_missing_from_live':sorted(set(frozen.nuts2)-set(r.nuts2)),'live_new_vs_archived':sorted(set(r.nuts2)-set(frozen.nuts2)),'changed_archived_cells':len(delta),'note':'Live provider releases can change; archive is frozen historical extract. The full JSON-stat downloads are NOT shipped with the current frozen archive.'}
    (SRC/'release_reconciliation_summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(summary,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
