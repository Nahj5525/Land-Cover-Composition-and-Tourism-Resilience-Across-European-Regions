#!/usr/bin/env python3
"""Assert the archived analysis matches key numeric outcomes; use after run_analysis.py and additional_checks.py."""
import math,json
from pathlib import Path
import pandas as pd
root=Path(__file__).resolve().parents[1]
df=pd.read_csv(root/'data/nuts2_analysis_183regions.csv')
panel=pd.read_csv(root/'data/nuts2_annual_panel_1464.csv')
reg=pd.read_csv(root/'results/regional_regressions_all.csv')
ml=pd.read_csv(root/'results/ml_grouped_cv.csv')
water=pd.read_csv(root/'results/water_sensitivity.csv')
assert len(df)==183 and df.nuts2.nunique()==183 and df.country.nunique()==21
assert len(panel)==1464 and panel.year.nunique()==8
assert (df.source_quality_flag=='flagged').sum()==17
f=lambda y:reg[(reg.year==y)&(reg.environment=='forest2018')].iloc[0]
assert math.isclose(f(2020).coef_per_10pctpt,2.2401783758,abs_tol=1e-5)
assert math.isclose(f(2020).q_BH_primary10,0.071229625,abs_tol=1e-5)
assert math.isclose(f(2024).coef_per_10pctpt,-0.7466975014,abs_tol=1e-5)
ww=water[(water.year==2024)&(water.specification=='exclude_NL')].iloc[0]
assert math.isclose(ww.water_p_cluster_t,0.46098,abs_tol=0.0001)
x=ml[(ml.year==2020)&(ml.model=='XGBoost + land cover')].iloc[0]
assert math.isclose(x.MAE,18.8341769,abs_tol=1e-4)
assert len(reg)==15 and len(ml)==10
print('PASS: 183 regions, 21 countries, 1464 year rows, all numeric sentinel checks.')
