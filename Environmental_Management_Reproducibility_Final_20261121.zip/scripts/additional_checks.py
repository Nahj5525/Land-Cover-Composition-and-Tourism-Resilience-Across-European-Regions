"""Post-estimation specificity checks for the water association and land-cover composition."""
from pathlib import Path
import json
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
ROOT=Path(__file__).resolve().parents[1];df=pd.read_csv(ROOT/'data/nuts2_analysis_183regions.csv')
def fit(z,y,form,weighted=False):
 if weighted:m=smf.wls(form,data=z,weights=(z.n2019/z.n2019.median())**.5).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
 else:m=smf.ols(form,data=z).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
 return m
result=[]
for yr in [2020,2024,2025]:
 for mode in ['main','exclude_FR_low_quality','exclude_NL','exclude_high_water_20pct','exclude_high_water_10pct','joint_landcover','weighted_tourism_size']:
  d=df.copy()
  if mode=='exclude_FR_low_quality':d=d[d.country!='FR']
  if mode=='exclude_NL':d=d[d.country!='NL']
  if mode=='exclude_high_water_20pct':d=d[d.water2018<20]
  if mode=='exclude_high_water_10pct':d=d[d.water2018<10]
  form=f'logratio{yr} ~ water2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)'
  if mode=='joint_landcover':form=f'logratio{yr} ~ water2018 + forest2018 + crop2018 + artificial2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)'
  m=fit(d,yr,form,weighted=(mode=='weighted_tourism_size'))
  b=m.params['water2018'];se=m.bse['water2018'];p=float(2*stats.t.sf(abs(b/se),df=d.country.nunique()-1))
  result.append({'year':yr,'specification':mode,'regions':len(d),'countries':d.country.nunique(),'water_beta_1pctpt':b,'water_beta_10pctpt':b*10,'water_se_1pctpt':se,'water_p_cluster_t':p})
pd.DataFrame(result).to_csv(ROOT/'results/water_sensitivity.csv',index=False,float_format='%.8f')
# and country specific case notes
extreme=df.nlargest(12,'water2018')[['nuts2','country','water2018','pctchange2020','pctchange2024','pctchange2025','n2019']]
extreme.to_csv(ROOT/'results/upper_water_regions.csv',index=False)
print(pd.DataFrame(result).query('year==2024').to_string(index=False))
