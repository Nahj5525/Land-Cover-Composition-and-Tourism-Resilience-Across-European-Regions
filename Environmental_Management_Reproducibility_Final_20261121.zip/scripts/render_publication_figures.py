#!/usr/bin/env python3
"""Regenerate manuscript-ready figures from archived NUTS 2 data/results.

All plotted estimates and points are read from stored numeric data. These are
rendering-only outputs: no regression coefficients are refitted or altered.
Figure 2 uses GISCO 2024 regional label points (never inferred polygons).
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import linregress
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FuncFormatter
from matplotlib.colors import Normalize, TwoSlopeNorm, ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
from pyproj import Transformer
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'figures'/'manuscript'
OUT.mkdir(parents=True,exist_ok=True)
DATA = ROOT/'data'
RESULTS = ROOT/'results'
D = pd.read_csv(DATA/'nuts2_analysis_183regions.csv',encoding='utf-8-sig')
annual = pd.read_csv(RESULTS/'annual_association.csv',encoding='utf-8-sig')
reg = pd.read_csv(RESULTS/'regional_regressions_all.csv',encoding='utf-8-sig')
ml = pd.read_csv(RESULTS/'ml_grouped_cv.csv',encoding='utf-8-sig')
DARK='#162B45';NAVY='#18436D';TEAL='#0D8C86';CORAL='#C65E56';GOLD='#C58A37';SLATE='#6A7C8D';TEXT='#223246';PALE='#EFF3F7';GRID='#E5E9EE'
plt.rcParams.update({
 'font.family':'serif','font.serif':['Tinos','Times New Roman','Liberation Serif'],
 'font.size':10.4, 'axes.labelsize':10.2, 'axes.titlesize':11.2,
 'xtick.labelsize':9.1, 'ytick.labelsize':9.1, 'legend.fontsize':9.1,
 'figure.facecolor':'white','axes.facecolor':'white',
 'savefig.facecolor':'white', 'axes.edgecolor':'#C5CDD6',
 'axes.linewidth':.7, 'axes.titleweight':'bold','text.color':TEXT,'axes.labelcolor':TEXT,
 'xtick.color':'#475569','ytick.color':'#475569', 'svg.fonttype':'none',
})
def axes_style(ax,grid='y'):
 ax.spines[['top','right']].set_visible(False)
 ax.spines[['left','bottom']].set_color('#B8C3CE')
 ax.tick_params(length=3,width=.6,color='#A9B4BF')
 if grid:ax.grid(axis=grid,color=GRID,lw=.72,zorder=0)
def save(fig,name):
 png=OUT/(name+'.png'); svg=OUT/(name+'.svg')
 fig.savefig(png,dpi=320,bbox_inches='tight',pad_inches=.11,facecolor='white')
 fig.savefig(svg,bbox_inches='tight',pad_inches=.11,facecolor='white')
 plt.close(fig)
 print(name, png.stat().st_size)

# 1. Recovery trajectories --------------------------------------------------
yrs=np.arange(2018,2026)
regional=[np.median(100*(D[f'n{y}']/D['n2019'])) for y in yrs]
weighted=[100*D[f'n{y}'].sum()/D['n2019'].sum() for y in yrs]
fig,ax=plt.subplots(figsize=(8.5,4.15))
fig.subplots_adjust(left=.095,right=.965,top=.89,bottom=.18)
ax.axvspan(2019.55,2021.45,color='#FAE9E5',zorder=0)
ax.axhline(100,ls=(0,(4,3)),lw=1.1,color='#9DA9B5',zorder=1)
ax.plot(yrs,regional,color=NAVY,lw=2.3,marker='o',ms=6.1,label='Median region',zorder=5)
ax.plot(yrs,weighted,color=TEAL,lw=2.2,ls=(0,(5,2)),marker='s',ms=5.6,label='2019-night-weighted',zorder=4)
ax.text(2020.45,112.2,'Initial disruption',ha='center',color=CORAL,fontsize=9.8,fontweight='bold')
ax.text(2023.4,100.9,'2019 baseline',ha='center',va='bottom',color=SLATE,fontsize=8.4)
for x in [2020,2024]:
 i=x-2018
 for y,off,c,tag in [(regional[i],3.0,NAVY,'Median'),(weighted[i],-4.4,TEAL,'Weighted')]:
  ax.annotate(f'{y:.1f}',(x,y),xytext=(2,off*2.1),textcoords='offset points',color=c,fontsize=9.1,ha='left',va='center',fontweight='bold')
ax.set_ylim(44,116);ax.set_xlim(2017.8,2025.2);ax.set_xticks(yrs)
ax.set_ylabel('Accommodation-night index (2019 = 100)');ax.set_xlabel('Year')
axes_style(ax,grid='y')
ax.legend(loc='upper center',bbox_to_anchor=(.53,1.14),frameon=False,ncol=2,columnspacing=2.0,handlelength=2.4)
save(fig,'Figure_1_Accommodation_Recovery')

# 2. Regional points on shared 2024 GISCO map frame --------------------------
G=pd.read_csv(DATA/'gisco_nuts2_label_positions_2024.csv')
geo=D.merge(G,on='nuts2',how='inner',validate='one_to_one')
assert len(geo)==183
shapes=json.loads((DATA/'europe_outline_simplified.json').read_text(encoding='utf-8'))
prj=Transformer.from_crs('EPSG:4326','EPSG:3035',always_xy=True)
x,y=prj.transform(geo.gisco_lon.values,geo.gisco_lat.values)
xx=x/1000; yy=y/1000
configs=[
 ('A  Woodland cover, 2018',geo.forest2018,'YlGn',Normalize(0,80),'Land area (%)', [0,20,40,60,80]),
 ('B  Initial disruption, 2020',geo.pctchange2020,'RdYlBu',Normalize(-90,0),'Change vs. 2019 (%)',[-90,-60,-30,0]),
 ('C  Later recovery, 2024',geo.pctchange2024,'RdBu',TwoSlopeNorm(vmin=-25,vcenter=0,vmax=35),'Change vs. 2019 (%)',[-25,-10,0,10,25,35]),
 ('D  Later recovery, 2025',geo.pctchange2025,'RdBu',TwoSlopeNorm(vmin=-25,vcenter=0,vmax=35),'Change vs. 2019 (%)',[-25,-10,0,10,25,35]),
]
fig,axs=plt.subplots(2,2,figsize=(9.2,10.2))
fig.subplots_adjust(left=.04,right=.96,bottom=.07,top=.96,wspace=.1,hspace=.19)
for (name,values,cmap,norm,cbl,ticks),ax in zip(configs,axs.flat):
 ax.set_aspect('equal');ax.set_facecolor('#F6F9FB')
 for key,color,lw in [('coast','#A9B7C6',.65),('borders','#CCD5DE',.45)]:
  for part in shapes[key]:
   seg=np.asarray(part)
   sx,sy=prj.transform(seg[:,0],seg[:,1])
   ax.plot(sx/1000,sy/1000,color=color,lw=lw,zorder=1,solid_capstyle='round')
 sc=ax.scatter(xx,yy,c=values, s=34, cmap=cmap,norm=norm,edgecolor='white',lw=.39,alpha=.99,zorder=5)
 ax.set_xlim(2400,6420);ax.set_ylim(1370,5260)
 ax.set_xticks([]);ax.set_yticks([])
 for spine in ax.spines.values():spine.set_color('#CBD4DE');spine.set_linewidth(.7)
 ax.set_title(name,loc='left',fontsize=10.9,color=DARK,pad=6,fontweight='bold')
 cb=fig.colorbar(sc,ax=ax,orientation='horizontal',fraction=.038,pad=.026,shrink=.87,aspect=31,ticks=ticks,extend='both' if name.startswith(('C','D')) else 'neither')
 cb.outline.set_visible(False);cb.ax.tick_params(labelsize=8.7,length=2,pad=2)
 cb.set_label(cbl,fontsize=8.5,labelpad=2)
fig.text(.5,.018,'GISCO 2024 NUTS 2 label points (n = 183); markers are not historical regional polygons.',ha='center',fontsize=9.4,color=SLATE)
save(fig,'Figure_2_NUTS2_Label_Point_Maps')

# 3. Two panel raw scatter with foreign-visitor composition overlay ----------
fig,axes=plt.subplots(1,2,figsize=(9.4,4.25))
fig.subplots_adjust(left=.085,right=.915,bottom=.19,top=.89,wspace=.22)
norm=Normalize(0,100)
for ax,yr,label in zip(axes,[2020,2024],['A  Initial disruption (2020)','B  Later recovery (2024)']):
 X=D.forest2018.to_numpy();Y=D[f'logratio{yr}'].to_numpy()
 sc=ax.scatter(X,Y,c=D.foreign_share2019,cmap='viridis',norm=norm,s=31,alpha=.8,
              edgecolors='#FFFFFF',linewidths=.33,zorder=3)
 m,b,r,p,se=linregress(X,Y)
 lineX=np.array([1.9,77.1]);ax.plot(lineX,b+m*lineX,ls=(0,(4,3)),color=CORAL,lw=1.75,zorder=4)
 ax.text(.98,.07,f'Unadjusted r = {r:+.2f}',ha='right',transform=ax.transAxes,fontsize=9.2,color=CORAL)
 ax.set_title(label,loc='left',color=DARK,pad=9)
 ax.set_xlim(0,80);ax.set_xticks([0,20,40,60,80]);ax.set_xlabel('2018 woodland share (%)')
 ax.set_ylabel('Accommodation-night change (log points)')
 axes_style(ax,grid='y')
cb=fig.colorbar(sc,ax=axes.ravel().tolist(),fraction=.028,pad=.016,shrink=.93)
cb.outline.set_visible(False);cb.ax.tick_params(labelsize=8.7)
cb.set_label('Foreign guest nights in 2019 (%)',fontsize=9)
fig.text(.5,.03,'Points represent individual regions; dashed lines describe raw associations without country or tourism controls.',ha='center',fontsize=9.1,color=SLATE)
save(fig,'Figure_3_Raw_Woodland_Associations')

# 4. Annual within-country estimates with country-clustered confidence CI ----
A=annual.copy().sort_values('year')
fig,ax=plt.subplots(figsize=(9.1,4.15))
fig.subplots_adjust(left=.11,right=.97,top=.91,bottom=.20)
ax.axhline(0,color='#738597',lw=1.1,ls=(0,(5,3)),zorder=1)
ax.axvspan(2019.72,2020.28,color='#EDF4FA',alpha=.7,zorder=0)
ax.axvspan(2023.72,2024.28,color='#EAF5F3',alpha=.7,zorder=0)
ax.plot(A.year,A.beta_woodland_10pp,color='#9AAEC0',lw=1.7,zorder=2,ls='--')
for _,d in A.iterrows():
 year=int(d.year);beta=d.beta_woodland_10pp
 col=NAVY if year==2020 else (TEAL if year==2024 else (CORAL if year==2025 else SLATE))
 marker='D' if year in (2020,2024) else 'o'
 ax.errorbar(year,beta,yerr=[[beta-d.low95],[d.high95-beta]],fmt=marker,
             markersize=7.3 if year in (2020,2024) else 5.8,
             color=col,ecolor=col,elinewidth=1.9,capsize=5,capthick=1.55,zorder=5)
 if year in (2020,2024,2025):
  dy=11 if year in (2020,2024) else -17
  ax.annotate(f'{beta:+.2f}',(year,beta),xytext=(8,dy),textcoords='offset points',color=col,fontsize=9.4,fontweight='bold')
ax.set_xlim(2019.6,2025.47);ax.set_xticks(A.year)
ax.set_ylim(-4.7,4.65)
ax.set_ylabel('Woodland coefficient per 10 pp (log points)')
ax.set_xlabel('Outcome year, benchmarked to 2019')
axes_style(ax,grid='y')
fig.text(.5,.035,'Diamonds denote the prespecified comparison years (2020 and 2024); 2025 is exploratory.',ha='center',color=SLATE,fontsize=9.4)
save(fig,'Figure_4_Annual_Woodland_Estimates')

# 5. Country-held-out model MAE: parallel readable lollipop ranking ---------
models=['Training-fold mean','Ridge controls','Ridge controls + land cover','Random Forest + land cover','XGBoost + land cover']
labels=['Training-fold mean','Ridge: controls','Ridge: + land cover','Random forest: + land cover','XGBoost: + land cover']
cols=[SLATE,'#6D93AB',TEAL,'#5B6FB2',CORAL]
fig,axes=plt.subplots(1,2,figsize=(9.4,4.45))
fig.subplots_adjust(left=.27,right=.973,top=.89,bottom=.18,wspace=.19)
for ax,yr,xxlim,step,title in zip(axes,[2020,2024],[(0,26),(0,8.4)],[5,2],['A  Initial disruption (2020)','B  Later recovery (2024)']):
 subset=ml[ml.year==yr].set_index('model')
 vals=np.array([float(subset.loc[m,'MAE']) for m in models]);best=int(np.argmin(vals))
 for i,(v,col) in enumerate(zip(vals,cols)):
  ax.plot([0,v],[i,i],color='#CDD6DF',lw=2.8,zorder=2,solid_capstyle='round')
  ax.scatter(v,i,s=105 if i==best else 83,marker='D' if i==best else 'o',color=col,
             edgecolor='white',linewidth=.8,zorder=4)
  ax.text(v-.48 if yr==2020 else v-.18,i,f'{v:.2f}',color=DARK,
          fontsize=9.1,ha='right',va='center',fontweight='bold' if i==best else 'normal')
 ax.set_yticks(range(5));ax.set_yticklabels(labels if yr==2020 else [])
 ax.invert_yaxis();ax.set_xlim(*xxlim)
 ax.set_xticks(np.arange(xxlim[0],xxlim[1],step))
 ax.set_xlabel('Mean absolute error (log points)')
 ax.set_title(title,loc='left',color=DARK,pad=10)
 axes_style(ax,grid='x')
 ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0)
fig.text(.62,.965,'Lower MAE is better; diamonds mark the best model',ha='center',va='center',color=SLATE,fontsize=9.3)
fig.text(.55,.038,'Out-of-fold predictions from five-fold country-grouped cross-validation; n = 183 regions.',ha='center',fontsize=9.3,color=SLATE)
save(fig,'Figure_5_Country_Heldout_MAE')

# 6. Supplemental presentation of phase contrast, not part of the five main figures
S=pd.read_csv(RESULTS/'forest_phase_wald.csv').iloc[0]
fig,ax=plt.subplots(figsize=(7.8,3.4))
fig.subplots_adjust(left=.19,right=.95,top=.88,bottom=.23)
for y,year,col in [(2,2020,NAVY),(1,2024,TEAL)]:
 r=annual[annual.year==year].iloc[0]
 ax.plot([r.low95,r.high95],[y,y],color=col,lw=2.5,zorder=3)
 ax.scatter([r.low95,r.high95],[y,y],color=col,s=16,zorder=4)
 ax.scatter(r.beta_woodland_10pp,y,marker='D',color=col,s=85,zorder=5)
 ax.text(r.high95+.19,y,f'{r.beta_woodland_10pp:+.2f}',fontsize=10,color=col,va='center')
ax.axvline(0,color='#91A1B0',lw=1,ls=(0,(3,3)))
ax.set_yticks([1,2]);ax.set_yticklabels(['2024 recovery','2020 disruption']);ax.set_ylim(.5,2.5);ax.set_xlim(-3.2,5.7)
ax.set_xlabel('Woodland coefficient per 10 pp (log points)');axes_style(ax,grid='x')
fig.text(.5,.95,f'2024 − 2020: {S.coef_diff_per10pp:+.2f} log points; country-clustered p = {S.p_t20:.4f}',ha='center',color=DARK,fontsize=11,fontweight='bold')
save(fig,'Supplementary_Phase_Contrast')
