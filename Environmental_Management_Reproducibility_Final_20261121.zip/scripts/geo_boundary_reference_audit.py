#!/usr/bin/env python3
"""Offline reproduction of country-level geography exclusion Wald sensitivity.
Uses archived 183-row data; geometry equivalence is NOT established by this script."""
from pathlib import Path
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
ROOT=Path(__file__).resolve().parents[1]
D=pd.read_csv(ROOT/'data/nuts2_analysis_183regions.csv')
COLS=['nuts2','country','forest2018','foreign_share2019','pretrend_2018_2019','log_baseline2019','logratio2020','logratio2024']
F='y ~ forest2018*C(phase) + (foreign_share2019+pretrend_2018_2019+log_baseline2019)*C(phase) + C(country)*C(phase)'
S=[('Full matched sample',D),('Conservative: exclude Italy, Netherlands, Portugal',D[~D.country.isin(['IT','NL','PT'])]),('Exclude Italy and Portugal',D[~D.country.isin(['IT','PT'])]),('Conservative plus exclude Croatia',D[~D.country.isin(['IT','NL','PT','HR'])]),('Conservative plus exclude flagged source cells',D[(~D.country.isin(['IT','NL','PT']))&(D.flag6=='______')])]
res=[]
for label,df in S:
 z=pd.concat([df[COLS].drop(columns='logratio2024').rename(columns={'logratio2020':'y'}).assign(phase='2020'),df[COLS].drop(columns='logratio2020').rename(columns={'logratio2024':'y'}).assign(phase='2024')],ignore_index=True)
 model=smf.ols(F,z).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
 k='forest2018:C(phase)[T.2024]';b=float(model.params[k]);se=float(model.bse[k]);g=df.country.nunique()
 res.append({'sample':label,'regions':len(df),'countries':g,'forest_beta_2020_per10pp':10*model.params['forest2018'],'forest_beta_2024_per10pp':10*(model.params['forest2018']+b),'phase_delta_2024minus2020_per10pp':10*b,'SE_country_cluster':10*se,'t_statistic':b/se,'p_t_countryclusters':float(2*stats.t.sf(abs(b/se),g-1)),'method':'Stacked OLS, country-by-phase FE, phase-specific covariates; country-cluster SE, t(G-1)'})
r=pd.DataFrame(res)
expected=pd.read_csv(ROOT/'results/NUTS_BOUNDARY_CONSERVATIVE_ROBUSTNESS.csv')
for name in ['phase_delta_2024minus2020_per10pp','SE_country_cluster','p_t_countryclusters']:
 assert max(abs(r[name]-expected[name]))<1e-7,(name,r[name].to_list(),expected[name].to_list())
assert len(D)==183 and D.country.nunique()==21
print('PASS: geography conservative-exclusion regressions reproduce archived results')
print(r[['sample','regions','countries','phase_delta_2024minus2020_per10pp','p_t_countryclusters']].round(6).to_string(index=False))
