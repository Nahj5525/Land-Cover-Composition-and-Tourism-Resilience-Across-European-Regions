#!/usr/bin/env python3
"""Offline, deterministic NUTS2 LUCAS 2018 × tourism guest-nights analysis.
Input: compact, lossless (for nights) Eurostat API-derived response extracts under data/.
Run from ZIP root with Python >=3.10: python scripts/run_analysis.py
Results: data/*.csv, results/*.csv/JSON, figures/*.png.
"""
from __future__ import annotations
import csv,json,math,hashlib,platform,sys
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data';OUT=ROOT/'results';FIG=ROOT/'figures'
for p in [DATA,OUT,FIG]: p.mkdir(parents=True,exist_ok=True)
SRC=DATA/'regional_source_encoded.txt';INTERIM=DATA/'regional_interim_2021_2023_encoded.txt'

def dec(s):
 return float('nan') if s=='_' else int(s,36)

def writecsv(x,f): x.to_csv(OUT/f,index=False,float_format='%.8f',encoding='utf-8-sig')
rows={}
for line in SRC.read_text().strip().splitlines():
 z=line.strip().split('|');assert len(z)==13,(z[0],len(z))
 g=z[0];n=[dec(x) for x in z[1:7]]; land=[dec(x)/10 for x in z[7:12]]
 rec={'nuts2':g,'country':g[:2], 'n2018':n[0], 'n2019':n[1], 'n2020':n[2], 'n2024':n[3], 'n2025':n[4], 'foreign2019':n[5], 'forest2018':land[0], 'crop2018':land[1], 'water2018':land[2], 'artificial2018':land[3], 'grass2018':land[4], 'flag6':z[12]}
 assert g not in rows and len(g)==4
 rows[g]=rec
for line in INTERIM.read_text().strip().splitlines():
 z=line.strip().split('|');assert len(z)==4 and z[0] in rows,(z[0],len(z))
 for y,v in zip([2021,2022,2023],z[1:]):rows[z[0]]['n'+str(y)]=dec(v)
df=pd.DataFrame(list(rows.values())).sort_values('nuts2').reset_index(drop=True)
assert len(df)==183 and df.country.nunique()==21
assert all(df['n'+str(y)].gt(0).all() for y in range(2018,2026))
assert df['n2019'].gt(df['foreign2019']).all()
assert df['forest2018'].between(0,100).all()
assert df[['forest2018','crop2018','water2018','artificial2018','grass2018']].le(100).all().all()
df['foreign_share2019']=100*df.foreign2019/df.n2019
df['pretrend_2018_2019']=100*np.log(df.n2019/df.n2018)
df['log_baseline2019']=np.log(df.n2019)
df['tourism_2019_million']=df.n2019/1e6
df['source_quality_flag'] = df.flag6.apply(lambda x: 'flagged' if x!='______' else 'unflagged')
for year in range(2018,2026):
 df['logratio'+str(year)]=100*np.log(df['n'+str(year)]/df.n2019)
 df['pctchange'+str(year)]=100*(df['n'+str(year)]/df.n2019-1)
# replicate counts, ids/period checks
country_counts=df.groupby('country').size().rename('regions').reset_index();country_counts.to_csv(OUT/'country_sample_counts.csv',index=False)
df.to_csv(DATA/'nuts2_analysis_183regions.csv',index=False,encoding='utf-8-sig',float_format='%.8f')
long=df.melt(id_vars=['nuts2','country','forest2018','crop2018','water2018','artificial2018','grass2018','foreign_share2019','pretrend_2018_2019','log_baseline2019','flag6'],value_vars=[f'n{y}' for y in range(2018,2026)],var_name='year',value_name='nights')
long['year']=long.year.str[1:].astype(int)
long['logratio_2019']=100*np.log(long.nights/long.nuts2.map(df.set_index('nuts2').n2019))
long.to_csv(DATA/'nuts2_annual_panel_1464.csv',index=False,encoding='utf-8-sig',float_format='%.8f')

# Concentration metrics and descriptive results
landcols=['forest2018','crop2018','water2018','artificial2018','grass2018']
covars=['foreign_share2019','pretrend_2018_2019','log_baseline2019']
pretty={'forest2018':'Woodland share (2018)','crop2018':'Cropland share (2018)','water2018':'Water cover (2018)','artificial2018':'Artificial land (2018)','grass2018':'Grassland share (2018)'}
means=[]
for k in landcols+covars+['pctchange2020','pctchange2024','pctchange2025','logratio2020','logratio2024','logratio2025']:
 x=df[k];means.append({'variable':k,'N':len(x),'mean':x.mean(),'sd':x.std(ddof=1),'median':x.median(),'min':x.min(),'max':x.max()})
writecsv(pd.DataFrame(means),'descriptive_statistics.csv')
# Country cluster with small-sample Student-t df G-1; FE include invariant region heterogeneity between countries
# no scalar corrections outside statsmodels cluster covariance
results=[]; all_fits={}
for yr in [2020,2024,2025]:
 for env in landcols:
  form=f'logratio{yr} ~ {env} + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)'
  mod=smf.ols(form,data=df).fit(cov_type='cluster',cov_kwds={'groups':df.country,'use_correction':True,'df_correction':True},use_t=True)
  a=mod.params[env]; se=mod.bse[env];ncluster=df.country.nunique();tval=a/se
  # conservative p / interval based on G-1 degrees of freedom
  p=float(2*stats.t.sf(abs(tval),df=ncluster-1)); q=stats.t.ppf(.975,ncluster-1)
  entry={'year':yr,'environment':env,'N':int(mod.nobs),'countries':ncluster,'coef_per_pctpt':float(a),'coef_per_10pctpt':float(10*a),'se_per_pctpt':float(se),'t_clusters':float(tval),'p_cluster_t20':p,'ci95low_per10pctpt':float(10*(a-q*se)),'ci95high_per10pctpt':float(10*(a+q*se)),'adj_R2':float(mod.rsquared_adj),'model':'OLS with country fixed effects, country cluster SE, t(G-1)'}
  results.append(entry);all_fits[(yr,env)]=mod
reg=pd.DataFrame(results)
# planned 5 land predictors x two phase outcomes family FDR
primary=reg.year.isin([2020,2024]);reg['q_BH_primary10']=np.nan;reg.loc[primary,'q_BH_primary10']=multipletests(reg.loc[primary,'p_cluster_t20'],method='fdr_bh')[1]
writecsv(reg,'regional_regressions_all.csv')

# Covariate information main effects for the two forest models
coefrows=[]
for yr in [2020,2024,2025]:
 m=all_fits[(yr,'forest2018')];
 for k in ['forest2018']+covars:
  coefrows.append({'year':yr,'variable':k,'beta':float(m.params[k]),'se':float(m.bse[k]),'p_cluster_t20':float(2*stats.t.sf(abs(m.params[k]/m.bse[k]),df=20))})
writecsv(pd.DataFrame(coefrows),'woodland_main_full_coefficients.csv')

# robustness: excluding flags, heavily influential singletons, France, and high-volume weights; outliers winsorized
rob=[]
for yr in [2020,2024]:
 for mode in ['main','exclude_quality_flags','exclude_france','countries_ge2','winsorized_2_98','weighted_2019_nights']:
  z=df.copy()
  if mode=='exclude_quality_flags':z=z[z.source_quality_flag=='unflagged'].copy()
  if mode=='exclude_france':z=z[z.country!='FR'].copy()
  if mode=='countries_ge2':
   ct=z.country.value_counts();z=z[z.country.map(ct).ge(2)].copy()
  if mode=='winsorized_2_98':
   a,b=z['logratio'+str(yr)].quantile([.02,.98]);z['outcome_y']=z['logratio'+str(yr)].clip(a,b)
  else:z['outcome_y']=z['logratio'+str(yr)]
  nclust=z.country.nunique()
  form='outcome_y ~ forest2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)'
  if mode=='weighted_2019_nights':
   # protects against excessive dominance with sqrt of baseline weights
   m=smf.wls(form,data=z,weights=np.sqrt(z.n2019/z.n2019.median())).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
  else:m=smf.ols(form,data=z).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
  tval=m.params['forest2018']/m.bse['forest2018']
  rob.append({'year':yr,'specification':mode,'N':int(m.nobs),'country_clusters':nclust,'coef_woodland_10pp':10*float(m.params['forest2018']),'SE_10pp':10*float(m.bse['forest2018']),'p_t_clusters':float(2*stats.t.sf(abs(tval),df=nclust-1))})
writecsv(pd.DataFrame(rob),'robustness.csv')

# country leave-one-out sensitivity, not treating 183 region draws as 183 independent countries
leave=[]
for yr in [2020,2024]:
 for country in df.country.unique():
  z=df[df.country!=country]
  m=smf.ols(f'logratio{yr} ~ forest2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)',data=z).fit(cov_type='cluster',cov_kwds={'groups':z.country,'use_correction':True},use_t=True)
  tt=m.params['forest2018']/m.bse['forest2018']
  leave.append({'year':yr,'left_out_country':country,'n_regions':len(z),'coef_woodland_10pp':10*m.params['forest2018'],'p_t_clusters':float(2*stats.t.sf(abs(tt),df=z.country.nunique()-1))})
writecsv(pd.DataFrame(leave),'leave_one_country_out.csv')

# ML: country-held-out 5 folds so the same country's environment isn't in both train and test
ML_targets=[2020,2024]
ML_defs=['Training-fold mean','Ridge controls','Ridge controls + land cover','Random Forest + land cover','XGBoost + land cover']
perf=[];preds=[];gkf=GroupKFold(n_splits=5)
for yr in ML_targets:
 y=df[f'logratio{yr}'].to_numpy();Xc=df[covars].to_numpy();Xe=df[covars+landcols].to_numpy();grp=df.country.to_numpy()
 for name in ML_defs:
  yy=np.full(len(df),np.nan)
  for fold,(tr,te) in enumerate(gkf.split(Xe,y,grp),1):
   if name=='Training-fold mean': pred=np.repeat(float(y[tr].mean()),len(te))
   else:
    X=Xc if name=='Ridge controls' else Xe
    if name.startswith('Ridge'):model=make_pipeline(StandardScaler(),Ridge(alpha=10))
    elif name.startswith('Random Forest'):model=RandomForestRegressor(n_estimators=220,max_features=.85,min_samples_leaf=4,random_state=20261114,n_jobs=1)
    else:model=XGBRegressor(n_estimators=180,max_depth=2,learning_rate=.04,subsample=.85,colsample_bytree=.85,reg_lambda=10,min_child_weight=8,random_state=20261114,n_jobs=1,objective='reg:squarederror')
    model.fit(X[tr],y[tr]);pred=model.predict(X[te])
   yy[te]=pred
   for i,v in zip(te,pred):preds.append({'year':yr,'model':name,'fold':fold,'country':grp[i],'nuts2':df.nuts2[i],'actual':y[i],'prediction':v})
  assert np.isfinite(yy).all()
  perf.append({'year':yr,'model':name,'N':len(y),'countries':df.country.nunique(),'MAE':mean_absolute_error(y,yy),'RMSE':np.sqrt(mean_squared_error(y,yy)),'CV':'5-fold GroupKFold by country'})
writecsv(pd.DataFrame(perf),'ml_grouped_cv.csv');writecsv(pd.DataFrame(preds),'ml_out_of_fold_predictions.csv')

# annual year vs 2019 woodland regression, country clustered (not event-study causal)
annual=[]
for y in range(2020,2026):
 m=smf.ols(f'logratio{y} ~ forest2018 + foreign_share2019 + pretrend_2018_2019 + log_baseline2019 + C(country)',data=df).fit(cov_type='cluster',cov_kwds={'groups':df.country,'use_correction':True},use_t=True)
 beta=10*m.params['forest2018']; se=10*m.bse['forest2018'];p=2*stats.t.sf(abs(beta/se),df=20);ci=stats.t.ppf(.975,20)*se
 annual.append({'year':y,'beta_woodland_10pp':beta,'low95':beta-ci,'high95':beta+ci,'p_t20':p,'median_regional_index':100*np.median(df['n'+str(y)]/df.n2019),'mean_regional_pct_change':df['pctchange'+str(y)].mean()})
writecsv(pd.DataFrame(annual),'annual_association.csv')

# transparent data checks
checks={'source_nuts2_rows':len(df),'unique_nuts2':int(df.nuts2.nunique()),'countries':int(df.country.nunique()),'annual_rows':len(long),'years':list(range(2018,2026)), 'max_nonmissing_nights':int(df[[f'n{y}' for y in range(2018,2026)]].notna().sum().sum()),'flags':df.flag6.value_counts().to_dict(),'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC,INTERIM]},'sample_by_country':dict(df.country.value_counts().sort_index()),'reconciliation_note':'Official tgs00111 NUTS2, not harmonised NUTS boundary versions; FR reliability/estimation flags carried.'}
(OUT/'QA_AND_PROVENANCE.json').write_text(json.dumps(checks,indent=2,default=lambda v: int(v) if hasattr(v,'item') else str(v)),encoding='utf8')

# figures clean journal style, monochrome by default
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':160})
fig,ax=plt.subplots(figsize=(7.2,3.6));x=list(range(2018,2026));a=[100*np.median(df[f'n{y}']/df.n2019) for y in x];b=[100*np.average(df[f'n{y}']/df.n2019,weights=df.n2019) for y in x];ax.plot(x,a,marker='o',color='#222',label='Regional median');ax.plot(x,b,marker='s',linestyle='--',color='#777',label='2019 nights-weighted');ax.axhline(100,color='#aaa',lw=1);ax.set_ylabel('2019 = 100');ax.set_xticks(x);ax.legend(frameon=False,ncol=2);fig.tight_layout();fig.savefig(FIG/'fig1_tourism_recovery_indices.png',dpi=220);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.2,3.2));
for ax,y in zip(axs,[2020,2024]):
 ax.scatter(df.forest2018,df[f'logratio{y}'],s=10,color='#666',alpha=.65)
 ax.set_title(f'{y}: unadjusted association');ax.set_xlabel('2018 woodland share (%)');ax.set_ylabel('Guest nights log change ×100')
fig.tight_layout();fig.savefig(FIG/'fig2_woodland_scatter.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.2,3.1));an=pd.DataFrame(annual);an=an[an.year>=2020];ax.errorbar(an.year,an.beta_woodland_10pp,yerr=[an.beta_woodland_10pp-an.low95,an.high95-an.beta_woodland_10pp],fmt='o-',color='#222',capsize=4);ax.axhline(0,lw=1,color='#999',linestyle='--');ax.set_xticks(range(2020,2026));ax.set_ylabel('Within-country woodland coefficient\nper 10 percentage points (log points)');fig.tight_layout();fig.savefig(FIG/'fig3_annual_clustered_coefficients.png',dpi=220);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(7.2,3.2));
for ax,yr in zip(axs,[2020,2024]):
 mm=pd.DataFrame(perf);z=mm[mm.year==yr];ax.barh(np.arange(len(z)),z.MAE,color=['#b0b0b0' if i else '#555' for i in range(len(z))]);ax.set_yticks(np.arange(len(z)));ax.set_yticklabels(z.model,fontsize=7);ax.invert_yaxis();ax.set_xlabel('Country-held-out MAE (log points)');ax.set_title(str(yr))
fig.tight_layout();fig.savefig(FIG/'fig4_grouped_ml_mae.png',dpi=220);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.0,3.5));ab=reg[(reg.environment=='forest2018')].sort_values('year');ax.errorbar(ab.year,ab.coef_per_10pctpt,yerr=[ab.coef_per_10pctpt-ab.ci95low_per10pctpt,ab.ci95high_per10pctpt-ab.coef_per_10pctpt],marker='o',linestyle='none',capsize=6,color='#333');ax.axhline(0,color='#aaa',lw=1);ax.set_xticks([2020,2024,2025]);ax.set_ylabel('Forest coefficient per 10 pp (log points)');fig.tight_layout();fig.savefig(FIG/'fig5_phase_estimates.png',dpi=220);plt.close(fig)
summary={'N_regions':len(df),'N_countries':int(df.country.nunique()),'N_panel':len(long),'descriptive':{str(y):{'median_index':float(100*np.median(df[f'n{y}']/df.n2019)),'mean_pctchange':float(df[f'pctchange{y}'].mean()),'weighted_index':float(100*df[f'n{y}'].sum()/df.n2019.sum())} for y in range(2018,2026)},'main':reg[reg.environment=='forest2018'].to_dict(orient='records'),'alternative':reg.to_dict(orient='records'),'ML':perf,'robustness':rob,'annual':annual,'notes':['Observational comparisons; no causal identification.','2018 LUCAS woodland as a land-cover proxy, not proximity to forest; 2018 land data and tourist metrics differ from predecessor country/place study.','Within country FE and country clustering; 2019 domestic-foreign share and pretrend controls.']}
(OUT/'MAIN_RESULTS.json').write_text(json.dumps(summary,indent=2,default=lambda v: float(v) if hasattr(v,'item') else str(v)),encoding='utf8')
print('SAMPLE',len(df),'COUNTRIES',df.country.nunique(),'PANEL',len(long))
print('MAIN\n',reg[reg.environment=='forest2018'][['year','coef_per_10pctpt','p_cluster_t20','ci95low_per10pctpt','ci95high_per10pctpt','adj_R2']].to_string(index=False))
print('ALL 2020/24\n',reg[reg.year.isin([2020,2024])][['year','environment','coef_per_10pctpt','p_cluster_t20','q_BH_primary10']].to_string(index=False))
print('CV\n',pd.DataFrame(perf).to_string(index=False))
print('ROBUSTNESS\n',pd.DataFrame(rob).to_string(index=False))
print('DESCRIPTIVE\n',pd.DataFrame(means).to_string(index=False))
