#!/usr/bin/env python3
"""Draw reproducible point-symbol Europe maps from GISCO NUTS 2 label points.
NO NUTS polygons are inferred: positions are official GISCO 2024 label points;
coast and border polylines are simplified from the archived low-resolution
Basemap boundary files. Input observations are the archived 183-region sample.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, Normalize
from pyproj import Transformer
ROOT=Path(__file__).resolve().parents[1]
DF=pd.read_csv(ROOT/'data/nuts2_analysis_183regions.csv',encoding='utf-8-sig')
G=pd.read_csv(ROOT/'data/gisco_nuts2_label_positions_2024.csv')
D=DF.merge(G,on='nuts2',how='inner',validate='one_to_one').sort_values('nuts2')
assert len(D)==183 and D.nuts2.nunique()==183, len(D)
shapes=json.loads((ROOT/'data/europe_outline_simplified.json').read_text(encoding='utf-8'))
projection=Transformer.from_crs('EPSG:4326','EPSG:3035',always_xy=True)
x,y=projection.transform(D.gisco_lon.to_numpy(),D.gisco_lat.to_numpy())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':10.5,'axes.titleweight':'bold'})
fig,axs=plt.subplots(2,2,figsize=(11.5,8.9),layout='constrained')
configs=[
 ('A  Pre-shock woodland cover (2018)',D.forest2018,'YlGn',Normalize(0,80),'Percent of NUTS 2 land area'),
 ('B  Initial tourism shock (2020)',D.pctchange2020,'RdBu',TwoSlopeNorm(vmin=-85,vcenter=0,vmax=85),'Change vs 2019 (%)'),
 ('C  Later recovery (2024)',D.pctchange2024,'RdBu',TwoSlopeNorm(vmin=-85,vcenter=0,vmax=85),'Change vs 2019 (%)'),
 ('D  Later recovery (2025)',D.pctchange2025,'RdBu',TwoSlopeNorm(vmin=-85,vcenter=0,vmax=85),'Change vs 2019 (%)'),
]
for (title,values,cmap,norm,cbar_label),ax in zip(configs,axs.ravel()):
 ax.set_aspect('equal');ax.set_facecolor('#f7fafb')
 for key,color,lw in [('coast','#9da8b2',.55),('borders','#d8dfe5',.4)]:
  for segment in shapes[key]:
   seg=np.array(segment);xx,yy=projection.transform(seg[:,0],seg[:,1]);ax.plot(xx/1000, yy/1000, color=color,lw=lw,zorder=1)
 s=ax.scatter(x/1000,y/1000,c=values.to_numpy(),s=33,cmap=cmap,norm=norm,
              linewidths=.38,edgecolors='white',alpha=.96,zorder=4,marker='o')
 ax.set_xlim(2350,6500);ax.set_ylim(1250,5300)
 ax.set_xticks([]);ax.set_yticks([])
 for spine in ax.spines.values():spine.set_edgecolor('#d8dfe5');spine.set_linewidth(.65)
 ax.set_title(title,pad=8,color='#152a3a')
 cbar=fig.colorbar(s,ax=ax,orientation='horizontal',pad=.025,shrink=.85,aspect=31)
 cbar.ax.tick_params(labelsize=8,pad=1,length=2);cbar.set_label(cbar_label,size=8)
fig.suptitle('Regional environmental amenities and accommodation-night trajectories',fontsize=13.5,fontweight='bold',color='#122436')
fig.text(.5,-.044,'183 matched NUTS 2 regions in 21 European countries. Official GISCO label points, not polygons; no interpolation.',ha='center',va='bottom',fontsize=8,color='#526170')
out=ROOT/'figures/fig5_regional_fourpanel_dot_maps.png';out.parent.mkdir(exist_ok=True)
fig.savefig(out,dpi=340,bbox_inches='tight',facecolor='white');plt.close(fig)
# Also editable-data map table for revision and independent reuse
D[['nuts2','country','gisco_lon','gisco_lat','forest2018','pctchange2020','pctchange2024','pctchange2025']].to_csv(ROOT/'data/map_points_183.csv',index=False,float_format='%.6f')
print('Map created:',out.name,'bytes',out.stat().st_size)
