#!/usr/bin/env python3
"""Check numerical cells in the separately supplied manuscript against the archived outputs.

Usage: python scripts/validate_manuscript_tables.py /absolute/path/to/manuscript.docx
This check does not require the manuscript to be contained in the replication ZIP.
"""
import argparse,csv,hashlib,math,re
from pathlib import Path
import pandas as pd
from docx import Document
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('manuscript',type=Path,help='Separate Word manuscript path')
args=parser.parse_args()
P=args.manuscript
if not P.exists():raise SystemExit(f'Cannot find separate manuscript: {P}')
doc=Document(P)
assert len(doc.tables)==8,len(doc.tables)
results=ROOT/'results'
desc=pd.read_csv(results/'descriptive_statistics.csv',encoding='utf-8-sig').set_index('variable')
reg=pd.read_csv(results/'regional_regressions_all.csv',encoding='utf-8-sig')
water=pd.read_csv(results/'water_sensitivity.csv')
ml=pd.read_csv(results/'ml_grouped_cv.csv',encoding='utf-8-sig')
phase=pd.read_csv(results/'forest_phase_wald_robustness.csv')
war=pd.read_csv(results/'war_border_vs2021_yearFE.csv')
rows=[]
def parse(raw):
 txt=str(raw).strip().replace('\u2212','-').replace('\u2013','-').replace('−','-').replace('+','').replace(',','')
 txt=txt.replace('%','').strip()
 if not txt:return None
 return float(txt)
def test(table,row,col,expected,source,threshold=0.0051):
 cell=doc.tables[table].rows[row].cells[col].text.strip()
 actual=parse(cell)
 if actual is None:raise AssertionError((table,row,col,cell))
 okay=abs(actual-float(expected))<=threshold
 rows.append({'table':table+1,'row':row,'column':col,'displayed':cell,'computed':float(expected),'source':source,'PASS':okay})
 if not okay:print('FAIL',table+1,row,col,repr(cell),float(expected),source)

# Table 2 (index 1), 2018 land cover and tourism outcome descriptives
names=['forest2018','crop2018','water2018','artificial2018','grass2018',
       'foreign_share2019','pretrend_2018_2019','pctchange2020','pctchange2024','pctchange2025']
for row,key in enumerate(names,1):
 for col,c in enumerate(['mean','sd','median','min','max'],1):
  test(1,row,col,desc.loc[key,c],f'results/descriptive_statistics.csv: {key}.{c}')
# Table 3 (index 2), woodland main models
for i,year in enumerate([2020,2024,2025],1):
 s=reg[(reg.year==year)&(reg.environment=='forest2018')].iloc[0]
 for col,field in [(1,'coef_per_10pctpt'),(3,'p_cluster_t20'),(4,'adj_R2'),(5,'N')]:
  test(2,i,col,s[field],f'results/regional_regressions_all.csv: {year} woodland.{field}',.0051 if col in [1] else (.00051 if col in [3,4] else .01))
 # CI stored as a text interval, check extracted two numeric entries
 txt=doc.tables[2].rows[i].cells[2].text
 vals=re.findall(r'[-−+]?\d+\.\d+',txt)
 if len(vals)!=2:raise AssertionError(('CI extraction',txt))
 for expected,v,side in zip([s.ci95low_per10pctpt,s.ci95high_per10pctpt],vals,['lo','hi']):
  actual=parse(v);okay=abs(actual-expected)<=.0051
  rows.append({'table':3,'row':i,'column':2,'displayed':v,'computed':float(expected),'source':f'results/regional_regressions_all.csv: {year} CI {side}','PASS':okay})
  if not okay:print('FAIL CI',i,side,v,expected)
# Table 4: planned 5x2 comparisons with FDR q
for i,key in enumerate(['forest2018','crop2018','water2018','artificial2018','grass2018'],1):
 for year,startcol in [(2020,1),(2024,4)]:
  s=reg[(reg.year==year)&(reg.environment==key)].iloc[0]
  for offset,field in [(0,'coef_per_10pctpt'),(1,'p_cluster_t20'),(2,'q_BH_primary10')]:
   test(3,i,startcol+offset,s[field],f'results/regional_regressions_all.csv: {year} {key}.{field}',.0051 if offset==0 else .00051)
# Table 5 water sensitivity
key5=['main','exclude_FR_low_quality','exclude_NL','exclude_high_water_20pct','exclude_high_water_10pct','joint_landcover','weighted_tourism_size']
for i,key in enumerate(key5,1):
 s=water[(water.year==2024)&(water.specification==key)].iloc[0]
 for col,field in [(1,'regions'),(2,'countries'),(3,'water_beta_10pctpt'),(4,'water_p_cluster_t')]:
  test(4,i,col,s[field],f'results/water_sensitivity.csv: {key}.{field}',.0051 if col==3 else (.00051 if col==4 else .01))
# Table 6 prediction metrics
model=['Training-fold mean','Ridge controls','Ridge controls + land cover','Random Forest + land cover','XGBoost + land cover']
for i,key in enumerate(model,1):
 for y,col in [(2020,1),(2024,3)]:
  s=ml[(ml.year==y)&(ml.model==key)].iloc[0]
  test(5,i,col,s['MAE'],f'results/ml_grouped_cv.csv: {y} {key}.MAE')
  test(5,i,col+1,s['RMSE'],f'results/ml_grouped_cv.csv: {y} {key}.RMSE')
# Table 7 phase contrast
keys7=['full','exclude_quality_flags','exclude_border4','countries_ge2','exclude_border4_and_france']
for i,key in enumerate(keys7,1):
 s=phase[phase.spec==key].iloc[0]
 for col,field in [(1,'N_regions'),(2,'forest_beta_2020_10pp'),(3,'forest_beta_2024_10pp'),(4,'phase_difference_2024_minus_2020'),(5,'p_t_clusters')]:
  test(6,i,col,s[field],f'results/forest_phase_wald_robustness.csv: {key}.{field}',.0051 if col in (2,3,4) else (.000051 if col==5 else .01))
# Table 8 war descriptive contrasts
for i,year in enumerate([2022,2023,2024,2025],1):
 s=war[war.year==year].iloc[0]
 for col,field in [(1,'coef_log_points'),(2,'se_cluster'),(3,'p_cluster_t20')]:
  test(7,i,col,s[field],f'results/war_border_vs2021_yearFE.csv: {year}.{field}',.0051 if col!=3 else .00051)

out=results/'MANUSCRIPT_TABLE_NUMERIC_QA.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
pass_count=sum(x['PASS'] for x in rows)
sha=hashlib.sha256(P.read_bytes()).hexdigest()
summary=(f'Manuscript SHA256: {sha}\nTables in manuscript: 8\nNumerical entries checked: {len(rows)}\n'
         f'PASS: {pass_count}; FAIL: {len(rows)-pass_count}\n'
         'Tables 1 (variable definitions) has no statistical estimates; Tables 2-8 checked against preserved outputs.\n'
         'Display rounding: 2-4 decimals according to manuscript column; no analysis estimates were changed.\n')
(results/'MANUSCRIPT_TABLE_NUMERIC_QA_SUMMARY.txt').write_text(summary,encoding='utf-8')
print(summary)
if pass_count!=len(rows):raise SystemExit('Manuscript statistics mismatch')
