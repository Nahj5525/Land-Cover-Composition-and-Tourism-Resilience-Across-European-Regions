#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
reg=pd.read_csv(R/'results'/'forest_phase_wald_robustness.csv')
war=pd.read_csv(R/'results'/'war_border_vs2021_yearFE.csv')
country=pd.read_csv(R/'data'/'ukraine_border_exposure.csv')
assert len(country)==183 and country.country.nunique()==21 and country.war_ua_land_border.sum()==37
assert set(country.loc[country.war_ua_land_border==1,'country'])=={'PL','SK','HU','RO'}
assert len(war)==4 and list(war.year)==[2022,2023,2024,2025]
assert all(war.N_treated_country_clusters==4)
assert all(war.p_cluster_t20>0.05)
assert np.isclose(reg.iloc[0].phase_difference_2024_minus_2020,-2.9868758771786053,atol=1e-7)
assert np.isclose(reg.iloc[0].p_t_clusters,0.0007374348080347505,atol=1e-7)
assert reg.loc[reg.spec=='exclude_border4','p_t_clusters'].iloc[0] < .01
assert reg.loc[reg.spec=='exclude_quality_flags','p_t_clusters'].iloc[0] < .01
print('VERIFIED: 183 regions / 21 countries / 37 border-exposed regions / 4 treated countries; four war contrasts; Wald phase result.')
