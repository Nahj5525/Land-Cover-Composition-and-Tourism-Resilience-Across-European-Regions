from pathlib import Path
from datetime import datetime, timezone
import numpy as np, pandas as pd, json, hashlib
from scipy import stats
import statsmodels.formula.api as smf
from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_BREAK

ROOT=Path(__file__).resolve().parents[1]
HOME=ROOT
D=ROOT/'data'; RES=ROOT/'results'; OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
orig=pd.read_csv(D/'nuts2_analysis_183regions.csv',encoding='utf-8-sig')
YEARS=list(range(2018,2026)); LC=['forest2018','crop2018','water2018','artificial2018','grass2018']
basecols=['nuts2','country']+[f'n{y}' for y in YEARS]+['foreign2019']+LC
old=orig[basecols].copy();old['tourism_code_exists']=True;old['land_code_exists']=True;old['source']='archived_183_regions';old['flag6']=orig.flag6

def unpack(x,scale=1):
    if x=='_' or x=='': return np.nan
    return int(x,36)/scale
rows=[]
for ln in (ROOT/'data/excluded_67_base36.txt').read_text().splitlines():
    geo,ts,foreign,lc=ln.strip().split('|')
    ts=ts.split('.');lc=lc.split('.')
    assert len(ts)==8 and len(lc)==5,(geo,ts,lc)
    row={'nuts2':geo,'country':geo[:2]}
    row.update({f'n{y}':unpack(z) for y,z in zip(YEARS,ts)})
    row['foreign2019']=unpack(foreign)
    row.update({k:unpack(z,10) for k,z in zip(LC,lc)})
    row['tourism_code_exists']=True
    row['land_code_exists']=geo not in ('ES63','ES64','ES70','FRA1','FRA2','FRA3','FRA4','FRA5','FRY1','FRY2','FRY3','FRY4','FRY5','PT20','PT30')
    row['source']='new_2026_11_15_study_frame_api_extract'
    row['flag6']=''
    rows.append(row)
raw=pd.concat([old,pd.DataFrame(rows)],ignore_index=True).sort_values('nuts2').reset_index(drop=True)
assert raw.nuts2.nunique()==len(raw)==250
raw.to_csv(D/'eurostat_studyframe_250_nuts2_source_cells.csv',index=False,encoding='utf-8-sig',float_format='%.8f')
mask0=raw.tourism_code_exists & raw.land_code_exists
positive=lambda s:pd.to_numeric(s,errors='coerce').gt(0)
mask1=mask0 & np.logical_and.reduce([positive(raw[f'n{y}']) for y in YEARS])
mask2=mask1 & raw.foreign2019.notna() & raw.foreign2019.ge(0) & raw.foreign2019.lt(raw.n2019)
mask3=mask2 & raw[LC].notna().all(axis=1)
assert [int(mask0.sum()),int(mask1.sum()),int(mask2.sum()),int(mask3.sum())]==[235,191,186,183],[(m.sum()) for m in (mask0,mask1,mask2,mask3)]
assert set(raw.loc[mask3,'nuts2'])==set(orig.nuts2)
funnel=pd.DataFrame([{'stage':'A. Tourism source geographic codes, within the 22-country frame','N':len(raw)}, {'stage':'B. Also present in 2018 LUCAS land-cover source','N':int(mask0.sum())}, {'stage':'C. Positive annual tourist nights in every year, 2018–2025','N':int(mask1.sum())}, {'stage':'D. Observed 2019 foreign nights, below total','N':int(mask2.sum())}, {'stage':'E. All five 2018 LUCAS cover percentages available','N':int(mask3.sum())}]);funnel.to_csv(RES/'STUDY_FRAME_250_SOURCE_AUDIT_20261115.csv',index=False)
audit=raw[['nuts2','country','tourism_code_exists','land_code_exists']].copy();audit['all_years_positive']=np.logical_and.reduce([positive(raw[f'n{y}']) for y in YEARS]);audit['foreign_valid']=raw.foreign2019.notna() & raw.foreign2019.ge(0) & raw.foreign2019.lt(raw.n2019);audit['land_5_available']=raw[LC].notna().all(axis=1);audit['selected']=mask3; audit.to_csv(RES/'STUDY_FRAME_250_ELIGIBILITY.csv',index=False)

# Actual change-log revisions at NUTS 2 level from the official 2016→2021 and 2021→2024 Eurostat correspondence tables.
# The 2016→2021 HR04 division is not within the 183-code retained sample; HR03 is unaffected by that listing.
# The 2021→2024 change sheet identifies IT ITH5 and ITI3 (boundary adjustment).
# NL31/NL33 old -> NL35/NL36 new; Portugal PT16, PT18, PT17 split/recode: none are in matched sample.
change_entries=[
    ('HR04','2016_to_2021','Croatia','Retired; replacement HR02 HR05 HR06','excluded'),
    ('ITH5','2021_to_2024','Italy','NUTS2 border adjustment between ITH59 and ITI31','included_flag'),
    ('ITI3','2021_to_2024','Italy','NUTS2 border adjustment between ITH59 and ITI31','included_flag'),
    ('NL31','2021_to_2024','Netherlands','Boundary change and recoding to NL35','excluded'),
    ('NL33','2021_to_2024','Netherlands','Boundary change and recoding to NL36','excluded'),
    ('NL35','2021_to_2024','Netherlands','New NUTS2 code, historical backcalculation','excluded'),
    ('NL36','2021_to_2024','Netherlands','New NUTS2 code, historical backcalculation','excluded'),
    ('PT16','2021_to_2024','Portugal','Centro split or regional shift','excluded'),
    ('PT18','2021_to_2024','Portugal','Alentejo split or regional shift','excluded'),
    ('PT17','2021_to_2024','Portugal','Lisbon region division','excluded'),
    ('PT19','2021_to_2024','Portugal','New region','excluded'),
    ('PT1A','2021_to_2024','Portugal','New region','excluded'),
    ('PT1B','2021_to_2024','Portugal','New region','excluded'),
    ('PT1C','2021_to_2024','Portugal','New region','excluded'),
    ('PT1D','2021_to_2024','Portugal','New region','excluded'),
]
change=pd.DataFrame(change_entries,columns=['nuts2','comparison','country','official_change_interpretation','prior_audit_status']);change['in_original_183']=change.nuts2.isin(orig.nuts2);change.to_csv(RES/'NUTS2_OFFICIAL_CHANGE_LOG_IMPACT.csv',index=False)
maskstable=~orig.nuts2.isin(['ITH5','ITI3']);stable=orig[maskstable].copy()
assert len(stable)==181 and stable.country.nunique()==21

# Refit exactly the established stacked country-cluster model, excluding only the two changed-border codes.
cols=['nuts2','country','forest2018','foreign_share2019','pretrend_2018_2019','log_baseline2019','logratio2020','logratio2024']
def phase_test(df,label):
    s=pd.concat([df[cols].rename(columns={'logratio2020':'y'}).drop(columns=['logratio2024']).assign(phase='2020'),df[cols].rename(columns={'logratio2024':'y'}).drop(columns=['logratio2020']).assign(phase='2024')],ignore_index=True)
    f='y ~ forest2018*C(phase) + (foreign_share2019+pretrend_2018_2019+log_baseline2019)*C(phase) + C(country)*C(phase)'
    model=smf.ols(f,s).fit(cov_type='cluster',cov_kwds={'groups':s.country,'use_correction':True},use_t=True)
    term='forest2018:C(phase)[T.2024]'; diff=10*float(model.params[term]);se=10*float(model.bse[term]);G=int(df.country.nunique());p=2*stats.t.sf(abs(diff/se),G-1)
    return dict(spec=label,N_regions=len(df),countries=G,forest_2020_coef_per10pp=10*float(model.params['forest2018']),forest_2024_coef_per10pp=10*float(model.params['forest2018']+model.params[term]),difference_2024_minus_2020=diff,SE=se,t=diff/se,p_cluster_t=p)

phase=[phase_test(orig,'original_183'),phase_test(stable,'boundary_change_log_stable_181'),phase_test(stable[stable.flag6=='______'],'boundary_stable_and_no_quality_flag'),phase_test(orig[~orig.country.isin(['IT','NL','PT'])],'conservative_exclude_3_countries'),phase_test(stable[~stable.country.isin(['HU','PL','RO','SK'])],'boundary_stable_exclude_ukraine_land_neighbors')]
res=pd.DataFrame(phase);res.to_csv(RES/'NUTS2_CHANGELOG_EXCLUSION_WALD_RECHECK.csv',index=False,float_format='%.9f')

meta={ 'access_date_utc':'2026-11-15 (web API text extract, exact time not supplied)', 'source_tourism_url':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/tgs00111?lang=EN&geoLevel=nuts2&sinceTimePeriod=2018', 'source_land_url':'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/lan_lcv_ovw?lang=EN&geoLevel=nuts2&time=2018','source_tourism_updated':'2026-10-20T23:00:00+0200', 'source_land_updated':'2025-07-25T23:00:00+0200', 'captured_source':'complete study-frame cell extraction for 250 four-character NUTS2 candidates, 22 countries, without full Europe-wide JSON-stat API response envelope; missing values remain NA','archived_current_selected':'183 rows retained from original frozen analysis package; new source cells for the 67 nonselected candidates; full source JSON downloads remain optional external recovery procedure', 'numeric_precision':'Tourism counts are integers; LUCAS land-cover shares have 0.1 percentage-point precision; NO data fabrication','geometry_validation':'Official NUTS 2016->2021 and NUTS 2021->2024 change sheets, not polygon intersection/IoU; two included codes ITH5 and ITI3 flagged and omitted in stability test','sources_change_2016_21':'https://ec.europa.eu/eurostat/documents/345175/629341/NUTS2021.xlsx','sources_change_2021_24':'https://ec.europa.eu/eurostat/documents/345175/629341/NUTS2021-NUTS2024.xlsx/2b35915f-9c14-6841-8197-353408c4522d?t=1717505289640','research_use_restrictions':'Official source is open public statistics; terms and appropriate citations apply' }
(D/'STUDY_FRAME_RAW_CELL_SNAPSHOT_PROVENANCE.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False),encoding='utf-8')

print('SOURCE FUNNEL',funnel.to_string(index=False))
print('STABLE PHASE RESULTS\n',res.to_string(index=False))
