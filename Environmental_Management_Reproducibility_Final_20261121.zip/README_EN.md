# Environmental Management replication archive (MANUSCRIPT NOT INCLUDED)

This archive contains the data, analytical scripts, stored numeric outputs, figures, and source documentation for the European NUTS 2 land-cover and tourism-resilience study. The final manuscript is delivered separately as `Environmental_Management_SSCI_Styled_Final_20261121.docx` and is not included in this ZIP.

To reproduce the numeric results, extract the archive, install Python 3.13 and `requirements.txt`, then run `run_all_windows.bat` (Windows) or `bash run_all_macos_linux.sh` (macOS/Linux). These scripts do not generate the Environmental Management Word manuscript.

Key sample: 183 NUTS 2 regions from 21 countries; 1,464 region-year observations in 2018–2025. The original sample screening contains 250 candidate geographic codes (183 frozen selected regional source cells plus 67 later-verified unselected source cells). It is not a byte-for-byte copy of the complete historical Eurostat API response. NUTS code/version audits do not establish exact historical polygon alignment. Existing logs describe prior runs, rather than guaranteeing a fresh run on any recipient's computer. Source/release limitations and variable definitions are documented in `SOURCE_PROVENANCE.md` and `DATA_DICTIONARY.csv`.

## 2026-11-21 final improvements

- `FINAL_DATASET_183_NUTS2.csv` and `FINAL_ANNUAL_PANEL_2018_2025.csv` provide direct access to final study data.
- `ESM_1.pdf` is Online Resource 1, cited in the separate Word manuscript.
- `figures/manuscript/Figure_1...Figure_5` contains the revised manuscript figures (PNG and editable SVG). The script `scripts/render_publication_figures.py` recreates them from saved source-cell values and estimation CSVs. Figure numbers in `figures/` outside the `manuscript/` subfolder are historical file names and do not correspond to the final Word figure sequence.
- `results/MANUSCRIPT_TABLE_NUMERIC_QA.csv` cross-checks 183 displayed cells in Tables 2–8. Re-run against the separate Word document with `python scripts/validate_manuscript_tables.py /path/to/Environmental_Management_SSCI_Styled_Final_20261121.docx`.
- Reproducibility is based on archived study-frame source cells, not full historical Eurostat JSON snapshots or area-harmonized NUTS polygons.
