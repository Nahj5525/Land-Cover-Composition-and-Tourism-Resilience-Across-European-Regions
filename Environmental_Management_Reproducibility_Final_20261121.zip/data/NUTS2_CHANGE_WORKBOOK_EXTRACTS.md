# Official NUTS2 changes – relevant verified entries

2016→2021, official Changes NUTS-2 sheet: HR04 ended; new HR02, HR05, HR06. Other listed European changes were minor Spanish name changes and Norwegian classifications. In matched sample, none is a materially changed region (HR03 retained).

2021→2024, official Changes NUTS-2 sheet: Italian ITH5 and ITI3 boundary adjustment along ITI31/ITH59; Netherlands NL31/NL33 replaced by NL35/NL36 after boundary adjustment; Portuguese PT16, PT17, PT18 split/recalculated into PT19, PT1A, PT1B, PT1C, PT1D. The final 183-code sample contains ITH5 and ITI3 but does not contain the affected NL and PT codes.

Original workbook URLs and retrieval metadata are in the accompanying Korean audit file. This transcription is a targeted audit summary, not a local copy of the original workbooks or GIS polygons.
