@echo off
cd /d "%~dp0"
py -3 scripts\run_analysis.py || goto :fail
py -3 scripts\additional_checks.py || goto :fail
py -3 scripts\verify_results.py || goto :fail
py -3 scripts\ukraine_war_analysis.py || goto :fail
py -3 scripts\geo_boundary_reference_audit.py || goto :fail
py -3 scripts\render_regional_maps.py || goto :fail
py -3 scripts\render_publication_figures.py || goto :fail
py -3 scripts\recheck_studyframe_and_nuts_changes.py || goto :fail
py -3 scripts\verify_war_revision.py || goto :fail
echo PASS: analysis and numerical validation completed. Manuscript is distributed separately.
exit /b 0
:fail
echo ERROR: Reproduction failed. Check Python and requirements.
exit /b 1
