# Replication archive clarification (2026-11-21)

This file records documentation repairs made to the archived 2026-11-16 material without rewriting its historical logs.

1. `REPRODUCTION_TEST_REPORT_20261116.md` refers to `scripts/verify_submission.py`, which is absent. The final package instead includes and has executed `scripts/verify_results.py`, `scripts/geo_boundary_reference_audit.py`, `scripts/verify_war_revision.py` and `scripts/validate_manuscript_tables.py` (the last requires the separate Word manuscript).
2. A stale reference to `GEOGRAPHY_BIBLIOGRAPHY_AUDIT_KR.md` was corrected to the included `NUTS_BOUNDARY_AND_SOURCE_AUDIT_KR_20261115.md`.
3. The original figures were kept as archived reproduction outputs. The main manuscript figures, with consistent manuscript numbering and a separate renderer, are stored under `figures/manuscript/`.
4. The prior manuscript version in the older READMEs was replaced by `Environmental_Management_SSCI_Styled_Final_20261121.docx`, delivered separately. The ZIP contains neither manuscript version.
5. The cited `ESM_1.pdf` is now included as Online Resource 1.

The numerical analysis dataset was not modified for cosmetic editing. Refer to `SOURCE_PROVENANCE.md` for the limitations of historical source releases and NUTS polygon harmonization.
